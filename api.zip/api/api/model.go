package api

type Slip struct {
	Id     int    `json:"id"`
	Advice string `json:"advice"`
	Date   string `json:"date"`
}

type Data struct {
	Slip         Slip   `json:"slip"`
	TotalResults string `json:"total_results"`
	Query        string `json:"query"`
	Slips        []Slip `json:"slips"`
}

type CatFact struct {
	Fact   string `json:"fact"`
	Length int    `json:"length"`
}
