package api

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
)

// func BtcPrice() {

// 	url := "https://api.coindesk.com/v1/bpi/currentprice/eur.json"
// 	req, err := http.Get(url)
// 	if err != nil {
// 		panic(err.Error())
// 	} else {
// 		data, err := ioutil.ReadAll(req.Body)
// 		if err != nil {
// 			fmt.Println("Error at the data stage: ", err)
// 		}
// 		// fmt.Println(string(data))
// 		var result ListResponse
// 		json.Unmarshal(data, &result)
// 		fmt.Println(result)
// 	}
// }

func Random(reqT string) string {

	// structure for making HTTP requests

	client := &http.Client{}

	// create a new request
	req, err := http.NewRequest("GET", "https://api.adviceslip.com/advice", nil)

	if err != nil {
		log.Fatal(err)
	}

	// executing a request with a record in the response variable

	resp, err := client.Do(req)
	if err != nil {
		log.Fatal(err)
	}

	// delayed closing of the request
	defer resp.Body.Close()

	// converting the request body into a set of bytes

	bodyByte, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}

	// declaration of a variable to write the received data

	var data Data

	// writing data to the structure
	err = json.Unmarshal(bodyByte, &data)
	if err != nil {
		log.Fatal(err)
	}

	result := ""
	switch reqT {
	case "id":
		result = fmt.Sprint(data.Slip.Id)
	case "advice":
		result = fmt.Sprint(data.Slip.Advice)
	}
	// return the data
	return result
}

func AdvicebyID(id string) string {

	// structure for making HTTP requests

	client := &http.Client{}

	// create a new request
	req, _ := http.NewRequest("GET", fmt.Sprintf("https://api.adviceslip.com/advice/%v", id), nil)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()

	bodyByte, _ := ioutil.ReadAll(resp.Body)

	var data Data

	_ = json.Unmarshal(bodyByte, &data)

	return data.Slip.Advice
}

func SearchingAdvice(query string, reqT string) []string {

	client := &http.Client{}

	req, _ := http.NewRequest("GET", fmt.Sprintf("https://api.adviceslip.com/advice/search/%v", query), nil)

	resp, err := client.Do(req)
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()

	bodyByte, _ := ioutil.ReadAll(resp.Body)

	var data Data

	_ = json.Unmarshal(bodyByte, &data)

	result := make([]string, 0)

	switch reqT {
	case "advices":
		for _, slip := range data.Slips {
			result = append(result, slip.Advice)
		}
	case "dates":
		for _, slip := range data.Slips {
			result = append(result, slip.Date)
		}
	}
	return result
}
