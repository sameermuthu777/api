package main

import (
	"example/api"
	"fmt"
)

func main() {

	fmt.Println("Advice Slip")

	advice := api.Random("advice")
	id := api.Random("id")

	advbyid := api.AdvicebyID(id)
	fmt.Println("Random Advice :", advice)
	fmt.Println("Random ID : ", id)
	fmt.Println("Search Advice Id:", advbyid)

	searchadvice := api.SearchingAdvice("joy", "advices")
	fmt.Println("Advice by search :", searchadvice)

	date := api.SearchingAdvice("joy", "dates")
	fmt.Println("Dates :", date)
}
